import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-l-admin',
  templateUrl: './l-admin.component.html',
  styleUrls: ['./l-admin.component.css']
})
export class LAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
